<div class="map">
    <div class="map-overlay">
        <h2>AMALFI TERMINAL</h2>

        <p>Piazza Flavio Gioia / Amalfi</p>
        <p>+39 089 871009</p>

        <h2 style="margin: 40px 0 0">Orari apertura</h2>
        <p>Lun / Dom ore 7:00 - 1:00</p>

        <a href="/contatti"><button type="button">CONTATTI</button></a>

        <img src="{{ URL::asset('images/bg_at.png') }}" alt="">
    </div>

    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d756.9540828745106!2d14.60220995833406!3d40.633932312517125!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xf16169030bb951c7!2sAmalfi+Terminal+Italian+Food+%26+Lounge+Bar!5e0!3m2!1sen!2sit!4v1525697700594" width="100%" height="650" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>