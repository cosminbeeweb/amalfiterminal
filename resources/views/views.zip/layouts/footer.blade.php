<footer>
    <img class="footer-logo" src="{{ URL::asset('images/logo.svg') }}" alt="Logo footer"/>
    <p class="info">CAFÈ <i class="fas fa-circle"></i> FOOD <i class="fas fa-circle"></i> EVENTI & LOUNGE</p>
    <p>© 2018 - TUTTI DIRITTI SONO RISERVATI - P.IVA 0000000000000</p>

    <div class="social-media">
        <a href="#">
            <i class="fab fa-facebook-f"></i>
        </a>

        <a href="#">
            <i class="fab fa-instagram"></i>
        </a>

        <a href="#">
            <i class="fab fa-youtube"></i>
        </a>
    </div>
</footer>